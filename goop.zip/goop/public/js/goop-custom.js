$(document).ready(function() {
       		    $("a[href='#top']").click(function() {
                        $("html, body").animate({
                            scrollTop: 0
                        }, "slow");
                        return false;
                    });
                    $("#update").on("click", function(e) {
                        var $icon = $(this).find(".glyphicon.glyphicon-repeat"),
                            animateClass = "glyphicon-refresh-animate";

                        $icon.addClass(animateClass);
                        // setTimeout is to indicate some async operation
                        window.setTimeout(function() {
                            $icon.removeClass(animateClass);
                        }, 2000);
                    });

});
/**
 * GOOP Library
 * 
 */


if (typeof GOOP == "undefined" || !GOOP)
{
   var GOOP = {};
}

/**
 * GOOP top-level constants namespace.
 * 
 * @namespace GOOP
 * @class GOOP.constants
 */
GOOP.constants = GOOP.constants || {};

GOOP.util = GOOP.util || {};

GOOP.util.log = function(msg) {
	console.log(msg);
}

GOOP.options = GOOP.options || {};

GOOP.DomainManager = GOOP.DomainManager || {};

// Domain Manager JavaScript
GOOP.DomainManager = 
{
	options: null,
	
	elIds: {
		
	
	},
	
	domainConfig: {
		incidents: {
			id: "incidents",
			columnId: "#column-2"
		},
		
		serviceRequests: {
			id: "serviceRequests",
			columnId: "#column-3"			
		}
	},
	
	init: function DomainManager_init(opts) 
	{
		var parent = this;
		parent.options = opts;
		
		var incidentsId = parent.domainConfig.incidents.id;
		var incidentsColumnId = parent.domainConfig.incidents.columnId;
		
		var serviceRequestsId = parent.domainConfig.serviceRequests.id;
		var serviceRequestsColumnId = parent.domainConfig.serviceRequests.columnId;
				
		parent.showIncidentsColumn(incidentsColumnId, serviceRequestsColumnId);
	},
	
	incidentsClickHandler: function DomainManager_incidentsClickHandler(e) {
		var eventData = e.data;
		var targetElement = $(e.target);
		var parent = eventData.processor;
		
		var incidentsColumnId = parent.domainConfig.incidents.columnId;
		var serviceRequestsColumnId = parent.domainConfig.serviceRequests.columnId;
		
		parent.showIncidentsColumn(incidentsColumnId, serviceRequestsColumnId);
	},
	
	serviceRequestsClickHandler: function DomainManager_serviceRequestsClickHandler(e) {
		var eventData = e.data;
		var targetElement = $(e.target);
		var parent = eventData.processor;
		
		var incidentsColumnId = parent.domainConfig.incidents.columnId;
		var serviceRequestsColumnId = parent.domainConfig.serviceRequests.columnId;
		
		parent.showServiceRequestsColumn(incidentsColumnId, serviceRequestsColumnId);		
	},		
	
	showIncidentsColumn: function DomainManager_showIncidentsColumn(incidentsColumnId, serviceRequestsColumnId) {
		jQuery(serviceRequestsColumnId).hide();
		jQuery(serviceRequestsColumnId).css('width', '0%');
		
		jQuery(incidentsColumnId).css('width', '100%');
		jQuery(incidentsColumnId).delay(1000).fadeIn('slow');
	},
	
	showServiceRequestsColumn: function DomainManager_showServiceRequestsColumn(incidentsColumnId, serviceRequestsColumnId) {
		jQuery(incidentsColumnId).hide();
		jQuery(incidentsColumnId).css('width', '0%');
		
		jQuery(serviceRequestsColumnId).css('width', '100%');
		jQuery(serviceRequestsColumnId).delay(1000).fadeIn('slow');	
	}
};



